-- ============================================================
-- Task 2: Query Optimization — Optimized SQL Queries
-- ============================================================

-- -------------------------------------------------------
-- Q1: Product Search (by category, price range, keyword)
-- Uses: idx_products_category, idx_products_price, idx_products_name_search
-- -------------------------------------------------------

-- Search by category
SELECT p.product_id, p.product_name, c.category_name, p.price, i.stock
FROM products p
JOIN categories c ON p.category_id = c.category_id
JOIN inventory i ON p.product_id = i.product_id
WHERE c.category_name = 'Electronics';

-- Search by price range
SELECT p.product_id, p.product_name, p.price, i.stock
FROM products p
JOIN inventory i ON p.product_id = i.product_id
WHERE p.price BETWEEN 1000.00 AND 10000.00
ORDER BY p.price ASC;

-- Search by keyword (full-text search using GIN index)
SELECT p.product_id, p.product_name, p.price,
       ts_rank(to_tsvector('english', p.product_name), plainto_tsquery('english', 'Laptop')) AS rank
FROM products p
WHERE to_tsvector('english', p.product_name) @@ plainto_tsquery('english', 'Laptop')
ORDER BY rank DESC;

-- -------------------------------------------------------
-- Q2: Top-Selling Products
-- Uses: idx_order_items_product (aggregate push-down)
-- -------------------------------------------------------
SELECT p.product_id, p.product_name, SUM(oi.quantity) AS total_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name
ORDER BY total_sold DESC
LIMIT 10;

-- -------------------------------------------------------
-- Q3: Customer Order History
-- Uses: idx_orders_customer, idx_order_items_order
-- -------------------------------------------------------
SELECT o.order_id, o.total_amount, o.status, o.created_at,
       oi.product_id, p.product_name, oi.quantity, oi.unit_price
FROM orders o
JOIN order_items oi ON o.order_id = oi.order_id
JOIN products p ON oi.product_id = p.product_id
WHERE o.customer_id = 1
ORDER BY o.created_at DESC;

-- -------------------------------------------------------
-- Q4: Daily Revenue Report
-- Uses: idx_orders_created, idx_orders_status
-- -------------------------------------------------------
SELECT DATE(o.created_at) AS report_date,
       COUNT(DISTINCT o.order_id) AS total_orders,
       SUM(o.total_amount) AS daily_revenue
FROM orders o
WHERE o.status IN ('Paid', 'Delivered')
GROUP BY DATE(o.created_at)
ORDER BY report_date DESC;

-- Monthly Revenue Report
SELECT DATE_TRUNC('month', o.created_at) AS report_month,
       COUNT(DISTINCT o.order_id) AS total_orders,
       SUM(o.total_amount) AS monthly_revenue
FROM orders o
WHERE o.status IN ('Paid', 'Delivered')
GROUP BY DATE_TRUNC('month', o.created_at)
ORDER BY report_month DESC;

-- -------------------------------------------------------
-- Q5: Low-Stock Product Alerts (stock < 15)
-- Uses: idx_inventory_stock
-- -------------------------------------------------------
SELECT p.product_id, p.product_name, i.stock, i.warehouse
FROM inventory i
JOIN products p ON i.product_id = p.product_id
WHERE i.stock < 15
ORDER BY i.stock ASC;

-- ============================================================
-- Query Execution Plan Examples (EXPLAIN ANALYZE)
-- ============================================================

-- Execution plan for product search by category
EXPLAIN ANALYZE
SELECT p.product_id, p.product_name, p.price
FROM products p
WHERE p.category_id = 1;

-- Execution plan for top-selling products
EXPLAIN ANALYZE
SELECT p.product_id, p.product_name, SUM(oi.quantity) AS total_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name
ORDER BY total_sold DESC
LIMIT 10;
