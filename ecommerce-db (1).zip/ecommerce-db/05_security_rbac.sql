-- ============================================================
-- Task 4: Security & Access Control
-- ============================================================

-- -------------------------------------------------------
-- PART A: Role-Based Access Control (RBAC)
-- -------------------------------------------------------

-- Create roles
CREATE ROLE admin_role;
CREATE ROLE seller_role;
CREATE ROLE customer_role;

-- Admin: Full access to all tables
GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO admin_role;
GRANT ALL PRIVILEGES ON ALL SEQUENCES IN SCHEMA public TO admin_role;
GRANT USAGE ON SCHEMA public TO admin_role;

-- Seller: Manage products and inventory, view orders for their products
GRANT SELECT, INSERT, UPDATE ON products TO seller_role;
GRANT SELECT, INSERT, UPDATE ON inventory TO seller_role;
GRANT SELECT ON categories TO seller_role;
GRANT SELECT ON orders TO seller_role;
GRANT SELECT ON order_items TO seller_role;
GRANT USAGE ON SCHEMA public TO seller_role;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO seller_role;

-- Customer: Place orders, view own data
GRANT SELECT ON products TO customer_role;
GRANT SELECT ON categories TO customer_role;
GRANT SELECT ON inventory TO customer_role;
GRANT SELECT, INSERT ON orders TO customer_role;
GRANT SELECT, INSERT ON order_items TO customer_role;
GRANT SELECT, INSERT ON payments TO customer_role;
GRANT USAGE ON SCHEMA public TO customer_role;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO customer_role;

-- Create specific users and assign roles
CREATE USER admin_user WITH PASSWORD 'AdminSecure@2024';
CREATE USER seller_user WITH PASSWORD 'SellerSecure@2024';
CREATE USER customer_user WITH PASSWORD 'CustomerSecure@2024';

GRANT admin_role TO admin_user;
GRANT seller_role TO seller_user;
GRANT customer_role TO customer_user;

-- -------------------------------------------------------
-- PART B: Row-Level Security (RLS) for Customers
-- Customers can only see their own orders
-- -------------------------------------------------------

ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY customer_orders_policy ON orders
    FOR SELECT
    USING (customer_id = current_setting('app.current_user_id')::INT);

-- Admin bypass
CREATE POLICY admin_orders_policy ON orders
    FOR ALL
    USING (current_user = 'admin_user');

-- -------------------------------------------------------
-- PART C: Data Protection — Encryption & Hashing
-- -------------------------------------------------------

-- Enable pgcrypto extension for encryption functions
CREATE EXTENSION IF NOT EXISTS pgcrypto;

-- Password hashing demonstration (using bcrypt via pgcrypto)
-- When inserting a new customer:
INSERT INTO customers (full_name, email, phone, password_hash, city)
VALUES (
    'Meron',
    'meron@example.com',
    '+251911000004',
    crypt('securePassword!', gen_salt('bf', 8)),  -- bcrypt hash
    'Addis Ababa'
);

-- Verifying password on login:
SELECT customer_id, full_name
FROM customers
WHERE email = 'meron@example.com'
  AND password_hash = crypt('securePassword!', password_hash);

-- Encrypting sensitive data (phone numbers, payment info)
-- Using pgp_sym_encrypt / pgp_sym_decrypt with a secret key

-- Create a table for encrypted payment details
CREATE TABLE payment_details_encrypted (
    detail_id     SERIAL PRIMARY KEY,
    payment_id    INT REFERENCES payments(payment_id),
    card_number   BYTEA,  -- encrypted
    phone_number  BYTEA,  -- encrypted
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert encrypted data
INSERT INTO payment_details_encrypted (payment_id, card_number, phone_number)
VALUES (
    1,
    pgp_sym_encrypt('4532-1234-5678-9012', 'encryption_secret_key'),
    pgp_sym_encrypt('+251911000001', 'encryption_secret_key')
);

-- Decrypt data (only authorized users with the key can read)
SELECT payment_id,
       pgp_sym_decrypt(card_number, 'encryption_secret_key') AS card_number,
       pgp_sym_decrypt(phone_number, 'encryption_secret_key') AS phone_number
FROM payment_details_encrypted
WHERE payment_id = 1;

-- -------------------------------------------------------
-- PART D: Audit Logging
-- -------------------------------------------------------

-- Login attempts tracking table
CREATE TABLE login_attempts (
    attempt_id    SERIAL PRIMARY KEY,
    email         VARCHAR(200) NOT NULL,
    success       BOOLEAN NOT NULL,
    ip_address    VARCHAR(45),
    user_agent    TEXT,
    attempted_at  TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_login_email ON login_attempts(email);
CREATE INDEX idx_login_time ON login_attempts(attempted_at);

-- Trigger function for automatic audit logging on orders
CREATE OR REPLACE FUNCTION log_order_changes()
RETURNS TRIGGER AS $$
BEGIN
    IF TG_OP = 'INSERT' THEN
        INSERT INTO audit_log (user_id, action, table_name, record_id, new_values)
        VALUES (NEW.customer_id, 'ORDER_CREATED', 'orders', NEW.order_id,
                row_to_json(NEW)::jsonb);
    ELSIF TG_OP = 'UPDATE' THEN
        INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values)
        VALUES (NEW.customer_id, 'ORDER_UPDATED', 'orders', NEW.order_id,
                row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb);
    ELSIF TG_OP = 'DELETE' THEN
        INSERT INTO audit_log (user_id, action, table_name, record_id, old_values)
        VALUES (OLD.customer_id, 'ORDER_DELETED', 'orders', OLD.order_id,
                row_to_json(OLD)::jsonb);
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_order_audit
    AFTER INSERT OR UPDATE OR DELETE ON orders
    FOR EACH ROW EXECUTE FUNCTION log_order_changes();

-- Trigger function for payment audit logging
CREATE OR REPLACE FUNCTION log_payment_changes()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO audit_log (action, table_name, record_id, old_values, new_values)
    VALUES (
        CASE TG_OP
            WHEN 'INSERT' THEN 'PAYMENT_CREATED'
            WHEN 'UPDATE' THEN 'PAYMENT_UPDATED'
        END,
        'payments',
        COALESCE(NEW.payment_id, OLD.payment_id),
        CASE WHEN TG_OP = 'UPDATE' THEN row_to_json(OLD)::jsonb ELSE NULL END,
        row_to_json(NEW)::jsonb
    );
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_payment_audit
    AFTER INSERT OR UPDATE ON payments
    FOR EACH ROW EXECUTE FUNCTION log_payment_changes();

-- Fraud detection: Flag suspicious activities
-- Example: Multiple failed login attempts
SELECT email, COUNT(*) AS failed_attempts
FROM login_attempts
WHERE success = FALSE
  AND attempted_at > NOW() - INTERVAL '1 hour'
GROUP BY email
HAVING COUNT(*) > 5;

-- Example: Unusually large orders
SELECT o.order_id, c.full_name, o.total_amount
FROM orders o
JOIN customers c ON o.customer_id = c.customer_id
WHERE o.total_amount > (
    SELECT AVG(total_amount) + 3 * STDDEV(total_amount)
    FROM orders
);
