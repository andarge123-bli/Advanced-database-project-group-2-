-- ============================================================
-- Task 1: Advanced Schema Design — DDL (3NF+ Normalized)
-- E-Commerce Platform for Ethiopia
-- ============================================================

-- 1. Categories
CREATE TABLE categories (
    category_id   SERIAL PRIMARY KEY,
    category_name VARCHAR(100) NOT NULL UNIQUE,
    description   TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 2. Products
CREATE TABLE products (
    product_id    SERIAL PRIMARY KEY,
    product_name  VARCHAR(200) NOT NULL,
    category_id   INT NOT NULL REFERENCES categories(category_id),
    price         DECIMAL(12,2) NOT NULL CHECK (price > 0),
    description   TEXT,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 3. Inventory (separated from Products for 3NF — no transitive dependency)
CREATE TABLE inventory (
    inventory_id  SERIAL PRIMARY KEY,
    product_id    INT NOT NULL UNIQUE REFERENCES products(product_id),
    stock         INT NOT NULL DEFAULT 0 CHECK (stock >= 0),
    warehouse     VARCHAR(100) DEFAULT 'Addis Ababa',
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 4. Customers
CREATE TABLE customers (
    customer_id   SERIAL PRIMARY KEY,
    full_name     VARCHAR(150) NOT NULL,
    email         VARCHAR(200) UNIQUE,
    phone         VARCHAR(20),
    password_hash VARCHAR(256) NOT NULL,
    city          VARCHAR(100) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 5. Orders
CREATE TABLE orders (
    order_id      SERIAL PRIMARY KEY,
    customer_id   INT NOT NULL REFERENCES customers(customer_id),
    total_amount  DECIMAL(12,2) NOT NULL DEFAULT 0,
    status        VARCHAR(20) NOT NULL DEFAULT 'Placed'
                  CHECK (status IN ('Placed','Paid','Shipped','Delivered','Cancelled')),
    shipping_city VARCHAR(100),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 6. Order Items (bridge table — many-to-many between orders and products)
CREATE TABLE order_items (
    order_item_id SERIAL PRIMARY KEY,
    order_id      INT NOT NULL REFERENCES orders(order_id),
    product_id    INT NOT NULL REFERENCES products(product_id),
    quantity      INT NOT NULL CHECK (quantity > 0),
    unit_price    DECIMAL(12,2) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 7. Payments
CREATE TABLE payments (
    payment_id    SERIAL PRIMARY KEY,
    order_id      INT NOT NULL REFERENCES orders(order_id),
    payment_method VARCHAR(50) NOT NULL
                   CHECK (payment_method IN ('Telebirr','Bank Transfer','Cash on Delivery')),
    amount        DECIMAL(12,2) NOT NULL,
    status        VARCHAR(20) NOT NULL DEFAULT 'Pending'
                  CHECK (status IN ('Pending','Completed','Failed','Refunded')),
    transaction_ref VARCHAR(100),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 8. Audit Log (for security & fraud detection)
CREATE TABLE audit_log (
    log_id        SERIAL PRIMARY KEY,
    user_id       INT,
    action        VARCHAR(100) NOT NULL,
    table_name    VARCHAR(100),
    record_id     INT,
    old_values    JSONB,
    new_values    JSONB,
    ip_address    VARCHAR(45),
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ============================================================
-- Indexing Strategies
-- ============================================================

-- Product search optimization
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_price ON products(price);
CREATE INDEX idx_products_name_search ON products USING gin(to_tsvector('english', product_name));

-- Order lookup optimization
CREATE INDEX idx_orders_customer ON orders(customer_id);
CREATE INDEX idx_orders_status ON orders(status);
CREATE INDEX idx_orders_created ON orders(created_at);

-- Payment lookup
CREATE INDEX idx_payments_order ON payments(order_id);
CREATE INDEX idx_payments_status ON payments(status);

-- Inventory
CREATE INDEX idx_inventory_product ON inventory(product_id);
CREATE INDEX idx_inventory_stock ON inventory(stock);

-- Audit log
CREATE INDEX idx_audit_user ON audit_log(user_id);
CREATE INDEX idx_audit_action ON audit_log(action);
CREATE INDEX idx_audit_created ON audit_log(created_at);

-- Order items
CREATE INDEX idx_order_items_order ON order_items(order_id);
CREATE INDEX idx_order_items_product ON order_items(product_id);

-- Customer city (for distributed queries)
CREATE INDEX idx_customers_city ON customers(city);
