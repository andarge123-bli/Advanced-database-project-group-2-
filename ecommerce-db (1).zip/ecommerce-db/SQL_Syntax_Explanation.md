# SQL Syntax Explanation Guide
## E-Commerce Platform — Group 2

This document explains every major SQL syntax used in our scripts, what it does, and why we used it.

---

## 1. CREATE TABLE

```sql
CREATE TABLE customers (
    customer_id   SERIAL PRIMARY KEY,
    full_name     VARCHAR(150) NOT NULL,
    email         VARCHAR(200) UNIQUE,
    city          VARCHAR(100) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `CREATE TABLE` | Creates a new table in the database | Defines the structure (schema) of where data will be stored |
| `SERIAL` | Auto-incrementing integer (1, 2, 3, ...) | Automatically assigns a unique ID to each new row — no manual numbering needed |
| `PRIMARY KEY` | Uniquely identifies each row | Ensures no two customers have the same ID; required for relationships between tables |
| `VARCHAR(150)` | Variable-length text up to 150 characters | Stores text data efficiently — only uses space actually needed |
| `NOT NULL` | Column cannot be left empty | Enforces that required data is always provided (e.g., every customer must have a name) |
| `UNIQUE` | No two rows can have the same value | Prevents duplicate emails — one account per email address |
| `TIMESTAMP` | Stores date and time | Records exactly when a record was created |
| `DEFAULT CURRENT_TIMESTAMP` | Automatically sets the time to "right now" | No need to manually insert the time — the database handles it |

---

## 2. REFERENCES (Foreign Key)

```sql
CREATE TABLE products (
    product_id   SERIAL PRIMARY KEY,
    category_id  INT NOT NULL REFERENCES categories(category_id)
);
```

**What it does:** Creates a link (relationship) between two tables. The `category_id` in `products` must match a real `category_id` that exists in the `categories` table.

**Why we use it:** This is called a **Foreign Key**. It enforces referential integrity — you cannot assign a product to a category that does not exist. If you try to insert a product with `category_id = 99` but category 99 does not exist, the database will reject the insert with an error.

---

## 3. CHECK Constraint

```sql
price DECIMAL(12,2) NOT NULL CHECK (price > 0)
status VARCHAR(20) NOT NULL CHECK (status IN ('Placed','Paid','Shipped','Delivered','Cancelled'))
```

**What it does:** Validates that data meets a condition before it is saved.

**Why we use it:** Prevents invalid data from entering the database. For example:
- A product cannot have a negative price
- An order's status can only be one of the five allowed values
- Without CHECK, someone could insert `status = 'Banana'` — which makes no sense

---

## 4. CREATE INDEX

```sql
CREATE INDEX idx_products_category ON products(category_id);
CREATE INDEX idx_products_name_search ON products USING gin(to_tsvector('english', product_name));
```

**What it does:** Creates a special lookup structure (like the index at the back of a book) so the database can find rows faster without scanning every row.

**Why we use it:** Without indexes, every query does a **Sequential Scan** (reads every single row). With indexes:
- `idx_products_category` — finding all Electronics products goes from O(n) → O(log n)
- The **GIN index** (`USING gin`) works with full-text search. `to_tsvector` converts text into searchable tokens. For example, searching for "Laptop" instantly finds matching products instead of doing a slow `LIKE '%Laptop%'` scan.

**B-tree vs GIN:**
- **B-tree**: Used for equality (`=`) and range (`<`, `>`, `BETWEEN`) comparisons
- **GIN (Generalized Inverted Index)**: Used for full-text search and array containment — stores every word/token and maps it to which rows contain it

---

## 5. SELECT with JOIN

```sql
SELECT p.product_id, p.product_name, c.category_name, p.price
FROM products p
JOIN categories c ON p.category_id = c.category_id
WHERE c.category_name = 'Electronics';
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `SELECT` | Specifies which columns to retrieve | We choose only what we need, not everything |
| `FROM products p` | The main table; `p` is an alias (shorthand) | Aliases make the query shorter and readable |
| `JOIN categories c ON ...` | Combines rows from two tables where the condition matches | Brings category name into the product results — data stored in separate tables is linked |
| `WHERE` | Filters rows to only those matching the condition | Returns only Electronics products, not all products |

**INNER JOIN vs LEFT JOIN:**
- **INNER JOIN** (or just `JOIN`): Only returns rows where both tables have a matching record
- **LEFT JOIN**: Returns all rows from the left table, even if there is no match in the right table (missing right-side data shows as NULL)

---

## 6. GROUP BY and Aggregate Functions

```sql
SELECT p.product_name, SUM(oi.quantity) AS total_sold
FROM order_items oi
JOIN products p ON oi.product_id = p.product_id
GROUP BY p.product_id, p.product_name
ORDER BY total_sold DESC
LIMIT 10;
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `SUM(oi.quantity)` | Adds up all quantity values in the group | Calculates total units sold per product |
| `AS total_sold` | Gives the result column a readable name (alias) | Makes output readable instead of showing `sum` |
| `GROUP BY` | Groups all rows with the same value together | Without this, SUM would add up quantities from ALL products into one number |
| `ORDER BY ... DESC` | Sorts results from highest to lowest | Puts the best-selling product first |
| `LIMIT 10` | Returns only the first 10 rows | We only want the top 10, not all thousands of products |

Other aggregate functions we use:
- `COUNT(*)` — counts the number of rows
- `AVG()` — calculates the average
- `STDDEV()` — calculates the standard deviation (used in fraud detection)

---

## 7. DATE_TRUNC and DATE()

```sql
-- Daily revenue
SELECT DATE(o.created_at) AS report_date, SUM(o.total_amount) AS daily_revenue
FROM orders o
GROUP BY DATE(o.created_at);

-- Monthly revenue
SELECT DATE_TRUNC('month', o.created_at) AS report_month, SUM(o.total_amount)
FROM orders o
GROUP BY DATE_TRUNC('month', o.created_at);
```

**What they do:**
- `DATE(created_at)` — extracts just the date portion (removes time), e.g., `2024-12-15`
- `DATE_TRUNC('month', created_at)` — truncates to the start of the month, e.g., `2024-12-01 00:00:00`

**Why we use them:** We want to group orders by day or month to produce revenue reports. Without these, every order has a unique timestamp and they would never group together.

---

## 8. EXPLAIN ANALYZE

```sql
EXPLAIN ANALYZE
SELECT p.product_id, p.product_name
FROM products p
WHERE p.category_id = 1;
```

**What it does:** Shows the query execution plan — how the database actually runs the query internally, including which indexes it uses and how long each step takes.

**Why we use it:** This is how we **prove** our indexes are working. The output tells us:
- Is it doing an **Index Scan** (fast) or **Sequential Scan** (slow)?
- What is the estimated and actual cost?
- How many rows were processed?

Example output comparison:
```
-- Without index:
Seq Scan on products (cost=0.00..450.00 rows=50 width=...)

-- With index:
Index Scan using idx_products_category on products (cost=0.12..8.20 rows=50 width=...)
```

The index version is dramatically cheaper (8.20 vs 450.00 cost units).

---

## 9. BEGIN / COMMIT / ROLLBACK (Transactions)

```sql
BEGIN;
  UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;
  INSERT INTO orders (customer_id, total_amount, status) VALUES (1, 15000, 'Placed');
  INSERT INTO payments (order_id, payment_method, amount) VALUES (1, 'Telebirr', 15000);
COMMIT;
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `BEGIN` | Starts a transaction block | All following statements are treated as ONE unit |
| `COMMIT` | Saves all changes permanently | Makes everything visible to other users at the same time |
| `ROLLBACK` | Cancels all changes since BEGIN | If anything fails, everything is undone — no partial updates |

**Why transactions are critical:** In e-commerce, placing an order involves multiple steps (deduct stock, create order, create payment). If the system crashes after deducting stock but before creating the order, the customer paid for nothing and the stock is gone. Transactions prevent this — either ALL steps succeed, or NONE of them happen. This is the **Atomicity** property of ACID.

---

## 10. SELECT ... FOR UPDATE (Locking)

```sql
BEGIN;
SELECT stock FROM inventory WHERE product_id = 1 FOR UPDATE;
-- Other transactions trying to read this row will WAIT here
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;
COMMIT;
```

**What it does:** Locks the selected row so no other transaction can modify it until this transaction finishes.

**Why we use it:** This solves the **Lost Update** problem. Without locking:
- User A reads stock = 1
- User B reads stock = 1 (at the same time)
- User A sets stock = 0 (buys the item)
- User B sets stock = 0 (also buys the item — OVERSOLD!)

With `FOR UPDATE`:
- User A locks the row and reads stock = 1
- User B tries to read but **waits** (blocked)
- User A updates stock = 0 and commits
- User B's lock is released, reads stock = 0, cannot purchase

This guarantees **no overselling of products**.

---

## 11. Isolation Levels

```sql
BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;
-- ... your queries ...
COMMIT;

BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED;
-- ... your queries ...
COMMIT;
```

**What they do:** Control how much one transaction can "see" the changes being made by other concurrent transactions.

| Level | Dirty Read | Lost Update | Non-Repeatable Read | Phantom Read |
|-------|-----------|-------------|--------------------|----|
| READ UNCOMMITTED | Possible | Possible | Possible | Possible |
| **READ COMMITTED** (PostgreSQL default) | Prevented | Possible | Possible | Possible |
| REPEATABLE READ | Prevented | Prevented | Prevented | Possible |
| **SERIALIZABLE** | Prevented | Prevented | Prevented | Prevented |

**Why we use SERIALIZABLE for critical operations:** It is the safest level. PostgreSQL runs transactions as if they were executed one after another (serially), detecting and aborting conflicts automatically. Used for order placement and payment processing.

**Why READ COMMITTED is the default:** Good balance — prevents the worst problems (dirty reads) while allowing high concurrency. Used for general browsing and reporting.

---

## 12. CREATE ROLE and GRANT (RBAC)

```sql
CREATE ROLE admin_role;
CREATE ROLE seller_role;
CREATE ROLE customer_role;

GRANT ALL PRIVILEGES ON ALL TABLES IN SCHEMA public TO admin_role;
GRANT SELECT, INSERT, UPDATE ON products TO seller_role;
GRANT SELECT ON products TO customer_role;

CREATE USER abel_admin WITH PASSWORD 'SecurePass@123';
GRANT admin_role TO abel_admin;
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `CREATE ROLE` | Creates a permission group | Roles are reusable — assign to multiple users |
| `GRANT ... TO` | Gives a role or user specific permissions | Controls who can do what (read, write, delete) |
| `ALL PRIVILEGES` | Full access: SELECT, INSERT, UPDATE, DELETE, etc. | Admin can do everything |
| `CREATE USER` | Creates a database login account | Separate accounts for separate access levels |

**Why we separate roles:** A customer should NEVER be able to delete products or see other customers' data. A seller should not be able to access payment records. RBAC enforces the **Principle of Least Privilege** — every user gets only the access they actually need.

---

## 13. Row-Level Security (RLS)

```sql
ALTER TABLE orders ENABLE ROW LEVEL SECURITY;

CREATE POLICY customer_orders_policy ON orders
    FOR SELECT
    USING (customer_id = current_setting('app.current_user_id')::INT);
```

**What it does:** Adds a filter at the database level so that each user automatically sees only their own rows.

**Why we use it:** Even if a developer forgets to add a `WHERE customer_id = ?` filter in the application code, the database itself enforces it. Customer Abel can never accidentally see Sara's orders. This is a **defense-in-depth** security measure.

---

## 14. pgcrypto — crypt() and pgp_sym_encrypt()

```sql
-- Store password (hashed, not plain text)
INSERT INTO customers (full_name, password_hash)
VALUES ('Abel', crypt('myPassword123', gen_salt('bf', 8)));

-- Verify password on login
SELECT * FROM customers
WHERE email = 'abel@example.com'
  AND password_hash = crypt('myPassword123', password_hash);

-- Encrypt sensitive data
pgp_sym_encrypt('+251911000001', 'secret_key')

-- Decrypt sensitive data
pgp_sym_decrypt(phone_column, 'secret_key')
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `crypt()` | Hashes a password using bcrypt | Passwords are NEVER stored as plain text — even database admins cannot read them |
| `gen_salt('bf', 8)` | Generates a bcrypt salt with cost factor 8 | Salt prevents rainbow table attacks; cost factor slows down brute force |
| `pgp_sym_encrypt()` | Encrypts data using AES symmetric encryption | Phone numbers and card numbers are unreadable without the key |
| `pgp_sym_decrypt()` | Decrypts previously encrypted data | Only authorized code with the key can read sensitive data |

**Why hashing is different from encryption:**
- **Hashing** (passwords): One-way — you cannot reverse it. You verify by hashing the input again and comparing.
- **Encryption** (phone, card): Two-way — you can decrypt with the key. Used when you need to read the data later.

---

## 15. CREATE TRIGGER and FUNCTION (Audit Logging)

```sql
CREATE OR REPLACE FUNCTION log_order_changes()
RETURNS TRIGGER AS $$
BEGIN
    INSERT INTO audit_log (user_id, action, table_name, record_id, old_values, new_values)
    VALUES (NEW.customer_id, 'ORDER_UPDATED', 'orders', NEW.order_id,
            row_to_json(OLD)::jsonb, row_to_json(NEW)::jsonb);
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_order_audit
    AFTER INSERT OR UPDATE OR DELETE ON orders
    FOR EACH ROW EXECUTE FUNCTION log_order_changes();
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `CREATE FUNCTION ... RETURNS TRIGGER` | Defines a function that runs automatically | Contains the audit logging logic |
| `$$` ... `$$` | Marks the start and end of the function body | PostgreSQL delimiter for multi-line function code |
| `NEW` | The new row being inserted/updated | Access the new data values |
| `OLD` | The row before it was updated/deleted | Access what the data was before the change |
| `row_to_json()::jsonb` | Converts an entire row to JSON format | Stores a snapshot of the data at that moment |
| `CREATE TRIGGER` | Attaches the function to a table event | Automatically fires whenever the specified action happens |
| `AFTER INSERT OR UPDATE OR DELETE` | The events that fire the trigger | Captures all types of changes |
| `FOR EACH ROW` | Runs once per affected row | If 5 rows are updated, the trigger fires 5 times |
| `LANGUAGE plpgsql` | The programming language for the function body | PostgreSQL's procedural language — supports IF, LOOP, variables |

**Why triggers for audit logging:** Developers might forget to add audit code in every application. Triggers run at the database level automatically — there is no way to bypass them, even if the application has a bug or someone runs SQL directly.

---

## 16. Table Partitioning (Distributed Design)

```sql
CREATE TABLE customers_distributed (
    customer_id SERIAL,
    city        VARCHAR(100) NOT NULL,
    PRIMARY KEY (customer_id, city)
) PARTITION BY LIST (city);

CREATE TABLE customers_addis PARTITION OF customers_distributed
    FOR VALUES IN ('Addis Ababa');

CREATE TABLE customers_hawassa PARTITION OF customers_distributed
    FOR VALUES IN ('Hawassa');
```

**What it does:** Splits one logical table into multiple physical tables (partitions) based on a column value.

**Why we use it:**
- **Performance**: Queries for Addis Ababa customers only scan the `customers_addis` partition — much faster than scanning all 3 cities together
- **Data locality**: Each city's data can physically live on a server in that city, reducing network latency for local queries
- **Manageability**: Old data (e.g., a whole year) can be dropped by deleting one partition instead of running a slow DELETE on millions of rows

**PARTITION BY LIST**: Rows go into partitions based on exact values (Addis Ababa → customers_addis, Hawassa → customers_hawassa). An alternative is `PARTITION BY RANGE` for date ranges (January orders → one partition, February → another).

---

## 17. DO Block (Anonymous Procedure)

```sql
DO $$
DECLARE
    v_stock INT;
    v_order_id INT;
BEGIN
    SELECT stock INTO v_stock FROM inventory WHERE product_id = 1 FOR UPDATE;

    IF v_stock < 1 THEN
        RAISE EXCEPTION 'Out of stock!';
    END IF;

    UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;

    INSERT INTO orders (customer_id, total_amount) VALUES (1, 15000)
    RETURNING order_id INTO v_order_id;

    RAISE NOTICE 'Order % created successfully', v_order_id;
EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Failed: %', SQLERRM;
END $$;
```

| Syntax | What it means | Why we use it |
|--------|--------------|---------------|
| `DO $$ ... $$` | Runs an anonymous code block (no function name needed) | One-time execution of procedural logic without creating a named function |
| `DECLARE` | Section where variables are declared | Variables store intermediate values like stock count or order ID |
| `v_stock INT` | A variable named v_stock of type integer | Holds the stock value retrieved from the database |
| `SELECT ... INTO v_stock` | Stores query result into a variable | Lets us use the value in IF conditions |
| `IF ... THEN ... END IF` | Conditional logic | Checks stock before deducting — prevents negative stock |
| `RAISE EXCEPTION` | Throws an error, triggers automatic rollback | If stock is insufficient, the entire transaction rolls back cleanly |
| `RETURNING order_id INTO v_order_id` | Gets the auto-generated ID immediately after insert | We need the new order's ID to create order items and payments |
| `EXCEPTION WHEN OTHERS THEN` | Catches any error | Handles unexpected failures gracefully with a message |
| `SQLERRM` | Built-in variable containing the error message | Shows what went wrong in the NOTICE output |

---

## 18. CHECKPOINT (Failure Recovery)

```sql
CHECKPOINT;
```

**What it does:** Forces PostgreSQL to write all "dirty" (modified but not yet saved) data pages from memory to disk, and records a checkpoint position in the WAL (Write-Ahead Log).

**Why we use it:** During a crash recovery, PostgreSQL only needs to replay WAL records from the most recent checkpoint onwards. More frequent checkpoints mean faster recovery after a crash — less WAL to replay. Without checkpoints, PostgreSQL would have to replay the entire WAL from the beginning after every crash.

---

## 19. JSONB Data Type

```sql
old_values JSONB,
new_values JSONB

-- Inserting JSONB
VALUES (..., '{"product": "Laptop", "quantity": 1}'::jsonb);

-- Building JSONB dynamically
jsonb_build_object('product_id', 1, 'quantity', 2, 'total', 15000)
```

**What it does:** Stores JSON (JavaScript Object Notation) data in a binary format that is efficiently queryable.

**Why we use it for audit logs:** Each order change can have a different structure — some changes affect the status, others affect the amount. JSONB lets us store the entire row snapshot without needing to define specific columns for every possible field. You can also query inside JSONB (e.g., `WHERE new_values->>'status' = 'Delivered'`).

**JSONB vs JSON:** JSONB stores data in a parsed binary format — faster to query, supports indexing. JSON stores raw text — preserves whitespace and key order but is slower to search.

---

## 20. HAVING Clause (Fraud Detection)

```sql
SELECT email, COUNT(*) AS failed_attempts
FROM login_attempts
WHERE success = FALSE
  AND attempted_at > NOW() - INTERVAL '1 hour'
GROUP BY email
HAVING COUNT(*) > 5;
```

**What it does:** Filters the results of a `GROUP BY` based on aggregate values.

**Why HAVING instead of WHERE:**
- `WHERE` filters individual rows **before** grouping
- `HAVING` filters groups **after** aggregation

In this fraud detection query:
1. `WHERE` first excludes successful logins and logins older than 1 hour
2. `GROUP BY` groups remaining rows by email address
3. `HAVING` then keeps only email addresses that have more than 5 failed attempts

You cannot write `WHERE COUNT(*) > 5` because COUNT does not exist at the WHERE stage — the grouping has not happened yet.

---

## Summary Table: Key Concepts

| Concept | Syntax | Purpose |
|---------|--------|---------|
| Schema Design | `CREATE TABLE`, `SERIAL`, `REFERENCES` | Defines data structure and relationships |
| Data Integrity | `NOT NULL`, `UNIQUE`, `CHECK` | Prevents invalid data |
| Performance | `CREATE INDEX`, `USING gin` | Speeds up queries dramatically |
| Transactions | `BEGIN`, `COMMIT`, `ROLLBACK` | Ensures all-or-nothing operations (ACID) |
| Concurrency | `FOR UPDATE`, Isolation Levels | Prevents race conditions and overselling |
| Security | `CREATE ROLE`, `GRANT`, `RLS` | Controls who can access what data |
| Encryption | `crypt()`, `pgp_sym_encrypt()` | Protects sensitive data at rest |
| Automation | `CREATE TRIGGER`, `CREATE FUNCTION` | Runs logic automatically on data changes |
| Distribution | `PARTITION BY LIST` | Splits data across regions for performance |
| Recovery | `WAL`, `CHECKPOINT` | Ensures data survives crashes |
| Analytics | `GROUP BY`, `HAVING`, `DATE_TRUNC` | Aggregates data for reports |
| Audit Trail | `JSONB`, `row_to_json()`, `OLD`/`NEW` | Captures full history of every change |
