# E-Commerce Platform — Advanced Database Systems Report

## Group 2

---

## Table of Contents

1. Introduction
2. Task 1: Advanced Schema Design
3. Task 2: Query Optimization
4. Task 3: Transactions & Concurrency Control
5. Task 4: Security & Access Control
6. Task 5: Distributed Database Design
7. Task 6: Failure Recovery
8. Conclusion
9. References

---

## 1. Introduction

This report presents the design and analysis of a scalable database system for a modern E-commerce platform operating across multiple cities in Ethiopia (Addis Ababa, Adama, and Hawassa). The platform supports online product browsing and ordering, secure payment processing through Telebirr, bank transfer, and cash on delivery, real-time inventory management, and order tracking with logistics coordination.

The system is designed to handle real-world challenges including high user traffic during promotional periods, concurrent purchases of limited-stock products, fraud detection, secure transactions, and distributed operations across multiple regions.

---

## 2. Task 1: Advanced Schema Design

### 2.1 Entity-Relationship Model

The database schema is fully normalized to Third Normal Form (3NF) and above. The key entities and their relationships are:

**Entities:**
- **Categories** — Product classification (Electronics, Fashion, Home & Kitchen)
- **Products** — Items available for purchase, linked to categories
- **Inventory** — Stock levels separated from products (3NF: eliminates transitive dependency)
- **Customers** — Registered users with hashed credentials
- **Orders** — Purchase transactions with lifecycle status tracking
- **Order_Items** — Bridge table resolving the many-to-many relationship between Orders and Products
- **Payments** — Payment records linked to orders with method and status tracking
- **Audit_Log** — Transaction history for security and fraud detection

**Relationships:**
- Categories 1:N Products (one category has many products)
- Products 1:1 Inventory (each product has one inventory record)
- Customers 1:N Orders (one customer places many orders)
- Orders 1:N Order_Items (one order has many items)
- Products 1:N Order_Items (one product appears in many order items)
- Orders 1:N Payments (one order can have multiple payment attempts)

### 2.2 ER Diagram

```
+------------+       +------------+       +------------+
| Categories |1-----N|  Products  |1-----1| Inventory  |
+------------+       +------------+       +------------+
| category_id|       | product_id |       |inventory_id|
| name       |       | name       |       | product_id |
| description|       | category_id|       | stock      |
| created_at |       | price      |       | warehouse  |
| updated_at |       | description|       | updated_at |
+------------+       | created_at |       +------------+
                      | updated_at |
                      +-----+------+
                            |N
                            |
                      +-----+------+
                      | Order_Items|
                      +------------+
                      |order_item_id|
                      | order_id   |
                      | product_id |
                      | quantity   |
                      | unit_price |
                      | created_at |
                      +-----+------+
                            |N
                            |
+------------+        +----+------+       +------------+
| Customers  |1------N|  Orders   |1-----N|  Payments  |
+------------+        +-----------+       +------------+
| customer_id|        | order_id  |       | payment_id |
| full_name  |        |customer_id|       | order_id   |
| email      |        |total_amount|      | method     |
| phone      |        | status    |       | amount     |
| password   |        |ship_city  |       | status     |
| city       |        | created_at|       | txn_ref    |
| created_at |        | updated_at|       | created_at |
| updated_at |        +-----------+       | updated_at |
+------------+                            +------------+

                      +------------+
                      | Audit_Log  |
                      +------------+
                      | log_id     |
                      | user_id    |
                      | action     |
                      | table_name |
                      | record_id  |
                      | old_values |
                      | new_values |
                      | ip_address |
                      | created_at |
                      +------------+
```

### 2.3 Normalization Analysis

**1NF:** All attributes contain atomic values. No repeating groups exist.

**2NF:** All non-key attributes are fully functionally dependent on the entire primary key. The Order_Items table uses a surrogate key (order_item_id) with separate foreign keys, ensuring no partial dependencies.

**3NF:** No transitive dependencies exist. Inventory data (stock, warehouse) is separated from Products to eliminate the transitive dependency: product_id -> product_name -> stock. Categories are in their own table rather than stored as attributes of Products.

### 2.4 Indexing Strategy

| Index | Table | Column(s) | Type | Purpose |
|-------|-------|-----------|------|---------|
| idx_products_category | products | category_id | B-tree | Category filter queries |
| idx_products_price | products | price | B-tree | Price range queries |
| idx_products_name_search | products | product_name | GIN (tsvector) | Full-text keyword search |
| idx_orders_customer | orders | customer_id | B-tree | Customer order history |
| idx_orders_status | orders | status | B-tree | Status filter queries |
| idx_orders_created | orders | created_at | B-tree | Date-based reporting |
| idx_payments_order | payments | order_id | B-tree | Payment lookup by order |
| idx_inventory_stock | inventory | stock | B-tree | Low-stock alerts |

---

## 3. Task 2: Query Optimization

### 3.1 Optimized Queries

Five key queries were optimized:

1. **Product Search** — Uses GIN index with `to_tsvector` for full-text search, B-tree index on category_id for category filtering, and B-tree on price for range queries.

2. **Top-Selling Products** — Aggregation query with GROUP BY and ORDER BY on SUM(quantity). Uses the index on order_items(product_id) for the join.

3. **Customer Order History** — Joins orders, order_items, and products using indexed foreign keys (customer_id, order_id, product_id).

4. **Daily/Monthly Revenue Reports** — Filters by status and groups by date using DATE() or DATE_TRUNC() functions. Uses composite index opportunity on (status, created_at).

5. **Low-Stock Alerts** — Simple range scan using idx_inventory_stock with WHERE stock < 15.

### 3.2 Index Usage Explanation

**B-tree indexes** are used for equality comparisons (=) and range queries (BETWEEN, <, >). PostgreSQL uses these for product category filtering, price range searches, and date-based reporting.

**GIN (Generalized Inverted Index)** is used for full-text search on product names. The `to_tsvector` function tokenizes text, and the GIN index allows rapid lookup of documents containing specific terms.

### 3.3 Query Execution Plans

Using EXPLAIN ANALYZE, we observe:
- **Category search**: Index Scan on idx_products_category (cost reduced from Seq Scan)
- **Full-text search**: Bitmap Index Scan on idx_products_name_search followed by Bitmap Heap Scan
- **Top-selling products**: Hash Join between order_items and products, with HashAggregate for grouping
- **Revenue report**: Index Scan on idx_orders_status with filter on created_at

### 3.4 Performance Improvements

| Query | Without Index | With Index | Improvement |
|-------|--------------|------------|-------------|
| Category filter | Seq Scan O(n) | Index Scan O(log n) | 10-100x faster |
| Full-text search | Seq Scan + LIKE | GIN Index Scan | 50-500x faster |
| Order history | Seq Scan on orders | Index Scan on customer_id | 10-50x faster |
| Low-stock alert | Seq Scan | Index Scan | 5-20x faster |

---

## 4. Task 3: Transactions & Concurrency Control

### 4.1 Concurrency Problems Demonstrated

**Lost Update:** Two concurrent sessions read the same stock value (10), both decrement by 1, and both write stock = 9. One update is lost — stock should be 8 but is 9.

**Dirty Read:** Session A updates stock to 0 but does not commit. Session B reads the uncommitted value (0) and acts on it. Session A then rolls back. Session B used invalid data.

**Non-Repeatable Read:** Session A reads stock = 50, then Session B updates stock to 45 and commits. When Session A reads again, it sees 45 — a different value within the same transaction.

### 4.2 Solutions Applied

**Isolation Levels:**
- `READ COMMITTED` (PostgreSQL default): Prevents dirty reads. Each statement sees only committed data.
- `SERIALIZABLE`: Prevents all anomalies. Transactions execute as if run serially. PostgreSQL detects conflicts and aborts one transaction.

**Explicit Locking (SELECT ... FOR UPDATE):**
The most practical solution for our e-commerce scenario. When a customer begins a purchase:
1. Lock the inventory row with `SELECT stock FROM inventory WHERE product_id = ? FOR UPDATE`
2. Check stock sufficiency
3. Deduct stock, create order, create payment
4. COMMIT releases the lock

Other transactions attempting to buy the same product wait at the lock until the first transaction completes.

**ACID Compliance:**
- **Atomicity**: Entire purchase (inventory deduction + order + payment) wrapped in a single transaction with ROLLBACK on failure
- **Consistency**: CHECK constraints ensure stock >= 0 and valid status values
- **Isolation**: FOR UPDATE locking prevents concurrent modification
- **Durability**: WAL ensures committed transactions survive crashes

---

## 5. Task 4: Security & Access Control

### 5.1 Role-Based Access Control (RBAC)

Three roles with distinct privileges:

| Role | Permissions |
|------|------------|
| Admin (admin_role) | Full access to all tables and sequences |
| Seller (seller_role) | SELECT/INSERT/UPDATE on products and inventory; SELECT on orders |
| Customer (customer_role) | SELECT on products, categories, inventory; INSERT on orders and payments |

Row-Level Security (RLS) is enabled on the orders table so customers can only view their own orders.

### 5.2 Data Protection

**Password Hashing:** Using pgcrypto's `crypt()` function with bcrypt (`gen_salt('bf', 8)`). Passwords are never stored in plain text.

**Encryption:** Sensitive data (phone numbers, payment card numbers) encrypted using `pgp_sym_encrypt()` with AES-256. Only authorized users with the decryption key can read the data.

### 5.3 Audit Logging

**Automatic triggers** on the orders and payments tables record every INSERT, UPDATE, and DELETE operation in the audit_log table, capturing:
- Who performed the action (user_id)
- What changed (old_values, new_values as JSONB)
- When it happened (created_at timestamp)

**Login attempt tracking** records all authentication attempts with success/failure status, enabling fraud detection by flagging accounts with excessive failed attempts.

**Fraud Detection Queries:**
- Flag accounts with >5 failed logins in one hour
- Flag orders with amounts exceeding 3 standard deviations above the mean

---

## 6. Task 5: Distributed Database Design

### 6.1 Distribution Strategy

The e-commerce platform operates across three cities: Addis Ababa, Hawassa, and Adama. We use **horizontal fragmentation** (partitioning) by region.

**Fragmentation Scheme:**

```
                    +-------------------+
                    |   Global Schema   |
                    | (Products, Cats)  |
                    +--------+----------+
                             |
            +----------------+----------------+
            |                |                |
   +--------+------+  +-----+--------+  +----+---------+
   | Addis Ababa   |  |   Hawassa    |  |    Adama     |
   | (Master)      |  |   (Slave)    |  |   (Slave)    |
   +---------------+  +--------------+  +--------------+
   | customers_AA  |  | customers_HW |  | customers_AD |
   | orders_AA     |  | orders_HW    |  | orders_AD    |
   | inventory_AA  |  | inventory_HW |  | inventory_AD |
   | (All products)|  | (Read replica)|  | (Read replica)|
   +---------------+  +--------------+  +--------------+
```

### 6.2 Horizontal Fragmentation

Customer and order data are partitioned by city using PostgreSQL's declarative partitioning (`PARTITION BY LIST`):

- `customers_addis` — customers from Addis Ababa
- `customers_hawassa` — customers from Hawassa
- `customers_adama` — customers from Adama

Similarly for orders (partitioned by shipping_city).

Product and category data remain globally accessible across all nodes since they are shared reference data.

### 6.3 Replication Strategy

We employ a **Master-Slave (Primary-Replica)** replication model:

- **Master (Addis Ababa):** Handles all write operations. Contains the complete dataset.
- **Slaves (Hawassa, Adama):** Read replicas for local query performance. Receive changes via PostgreSQL logical replication.

**Why Master-Slave over Multi-Master:**
- Simpler conflict resolution (no write-write conflicts)
- Stronger data consistency guarantees
- Sufficient for our use case where writes originate primarily from online orders (can be routed to master)

### 6.4 Data Consistency Approach

We use **eventual consistency** for read replicas with the following guarantees:

- **Replication lag:** Typically < 1 second under normal load
- **Critical writes:** All order placements and payments are routed to the master, ensuring strong consistency for financial transactions
- **Read-after-write:** For the session that wrote the data, reads are directed to the master to ensure the user sees their own changes immediately

### 6.5 CAP Theorem Trade-offs

According to the CAP theorem, a distributed system can guarantee only two of three properties: Consistency, Availability, and Partition tolerance.

Our system prioritizes **Consistency and Partition Tolerance (CP):**

| Property | Our Approach |
|----------|-------------|
| Consistency | Strong for writes (master), eventual for reads (replicas) |
| Availability | High — replicas handle read traffic; master handles writes |
| Partition Tolerance | If a slave disconnects, reads degrade but writes continue on master |

**Trade-off:** During a network partition between master and slave, slave nodes serve potentially stale data. However, all financial transactions (orders, payments) remain consistent because they go through the master.

---

## 7. Task 6: Failure Recovery

### 7.1 Write-Ahead Logging (WAL)

PostgreSQL uses WAL as its primary crash recovery mechanism. Before any change is written to the actual data files, it is first recorded in the WAL (a sequential log on disk).

**How WAL works:**
1. Transaction begins and modifies data in memory (shared buffers)
2. Changes are written to WAL files on disk
3. WAL write is confirmed (fsync)
4. Transaction can be committed (durability guaranteed)
5. Modified data pages are written to disk later (asynchronously)

**Key configuration:**
- `wal_level = replica` — enables WAL for recovery and replication
- `archive_mode = on` — archives WAL files for point-in-time recovery
- `wal_keep_size = 1GB` — retains recent WAL files

### 7.2 Checkpointing

Checkpoints are periodic operations that flush all dirty (modified) data pages from memory to disk and record a checkpoint position in the WAL.

**Purpose:** Reduces recovery time by providing a known-consistent starting point. During crash recovery, PostgreSQL only needs to replay WAL records after the last checkpoint.

**Configuration:**
- `checkpoint_timeout = 5min` — maximum time between checkpoints
- `checkpoint_completion_target = 0.9` — spreads I/O over 90% of the interval
- `max_wal_size = 2GB` — triggers checkpoint when WAL exceeds this size

### 7.3 Crash Recovery Scenario

**Scenario:** The system crashes during a purchase transaction (after inventory deduction and order creation, but before payment insertion and COMMIT).

**Recovery Process:**
1. PostgreSQL restarts and enters recovery mode
2. Locates the last checkpoint in the WAL
3. **REDO phase:** Replays all committed transactions from WAL after the checkpoint
4. **UNDO phase:** Rolls back all uncommitted transactions
5. Since the purchase transaction was not committed, ALL its changes are undone:
   - Inventory stock is restored to the original value
   - The order record is removed
   - No payment record was created
6. Database returns to a consistent state — as if the failed transaction never occurred

### 7.4 Backup and Restore Strategies

| Strategy | Tool | Frequency | Recovery Time | Data Loss |
|----------|------|-----------|---------------|-----------|
| Logical backup | pg_dump | Daily | Minutes-Hours | Up to 24 hours |
| Physical backup | pg_basebackup | Daily | Minutes | Up to 24 hours |
| PITR (WAL archiving) | WAL + base backup | Continuous | Minutes | Seconds |
| Streaming replication | Built-in | Real-time | Seconds (failover) | Near-zero |

**Recommended strategy:** Combine daily physical backups with continuous WAL archiving for Point-in-Time Recovery (PITR). This allows restoring the database to any specific moment, minimizing data loss to seconds.

---

## 8. Conclusion

This report presented a comprehensive database system design for an E-commerce platform operating across multiple Ethiopian cities. The system addresses all critical requirements:

- **Schema Design:** Fully normalized 3NF schema with proper indexing strategies for optimal query performance
- **Query Optimization:** Indexed queries using B-tree and GIN indexes with demonstrated execution plan improvements
- **Concurrency Control:** ACID-compliant transactions using explicit locking (SELECT ... FOR UPDATE) and appropriate isolation levels to prevent overselling
- **Security:** Multi-layer security with RBAC, row-level security, bcrypt password hashing, AES encryption for sensitive data, and comprehensive audit logging
- **Distribution:** Horizontal fragmentation with master-slave replication balancing consistency and availability across regions
- **Recovery:** Write-ahead logging, checkpointing, and point-in-time recovery ensuring data durability and minimal downtime

The design handles real-world challenges including high concurrent user traffic, limited-stock product purchases, fraud detection, and distributed operations across Addis Ababa, Hawassa, and Adama.

---

## 9. References

1. PostgreSQL Documentation — https://www.postgresql.org/docs/
2. Silberschatz, Korth, Sudarshan. "Database System Concepts," 7th Edition, McGraw-Hill, 2019.
3. Ramakrishnan, Gehrke. "Database Management Systems," 3rd Edition, McGraw-Hill, 2003.
4. PostgreSQL WAL Documentation — https://www.postgresql.org/docs/current/wal-intro.html
5. PostgreSQL Partitioning — https://www.postgresql.org/docs/current/ddl-partitioning.html
6. PostgreSQL Row-Level Security — https://www.postgresql.org/docs/current/ddl-rowsecurity.html
