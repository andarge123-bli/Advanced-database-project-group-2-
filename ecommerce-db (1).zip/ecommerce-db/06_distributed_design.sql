-- ============================================================
-- Task 5: Distributed Database Design
-- ============================================================
-- This file contains SQL implementations for distributed design concepts.
-- The full explanation is in the report document.

-- -------------------------------------------------------
-- Horizontal Fragmentation by Region
-- Partitioning customers and orders by city/region
-- -------------------------------------------------------

-- Partitioned Customers Table (by city)
CREATE TABLE customers_distributed (
    customer_id   SERIAL,
    full_name     VARCHAR(150) NOT NULL,
    email         VARCHAR(200),
    phone         VARCHAR(20),
    password_hash VARCHAR(256) NOT NULL,
    city          VARCHAR(100) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (customer_id, city)
) PARTITION BY LIST (city);

-- Create partitions for each region
CREATE TABLE customers_addis PARTITION OF customers_distributed
    FOR VALUES IN ('Addis Ababa');

CREATE TABLE customers_hawassa PARTITION OF customers_distributed
    FOR VALUES IN ('Hawassa');

CREATE TABLE customers_adama PARTITION OF customers_distributed
    FOR VALUES IN ('Adama');

-- Partitioned Orders Table (by shipping city)
CREATE TABLE orders_distributed (
    order_id      SERIAL,
    customer_id   INT NOT NULL,
    total_amount  DECIMAL(12,2) NOT NULL DEFAULT 0,
    status        VARCHAR(20) NOT NULL DEFAULT 'Placed',
    shipping_city VARCHAR(100) NOT NULL,
    created_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (order_id, shipping_city)
) PARTITION BY LIST (shipping_city);

CREATE TABLE orders_addis PARTITION OF orders_distributed
    FOR VALUES IN ('Addis Ababa');

CREATE TABLE orders_hawassa PARTITION OF orders_distributed
    FOR VALUES IN ('Hawassa');

CREATE TABLE orders_adama PARTITION OF orders_distributed
    FOR VALUES IN ('Adama');

-- -------------------------------------------------------
-- Replication Configuration (Conceptual — PostgreSQL Logical Replication)
-- Master-Slave replication setup commands
-- -------------------------------------------------------

-- On the MASTER server (Addis Ababa):
-- CREATE PUBLICATION ecommerce_pub FOR ALL TABLES;

-- On SLAVE servers (Hawassa, Adama):
-- CREATE SUBSCRIPTION ecommerce_sub_hawassa
--     CONNECTION 'host=master_ip dbname=ecommerce user=replicator password=secret'
--     PUBLICATION ecommerce_pub;

-- CREATE SUBSCRIPTION ecommerce_sub_adama
--     CONNECTION 'host=master_ip dbname=ecommerce user=replicator password=secret'
--     PUBLICATION ecommerce_pub;

-- -------------------------------------------------------
-- Cross-Region Query Example
-- Query that spans multiple partitions transparently
-- -------------------------------------------------------

-- This query automatically checks all partitions
SELECT customer_id, full_name, city
FROM customers_distributed
WHERE city IN ('Addis Ababa', 'Hawassa', 'Adama');

-- Regional revenue report
SELECT shipping_city, SUM(total_amount) AS regional_revenue
FROM orders_distributed
GROUP BY shipping_city
ORDER BY regional_revenue DESC;
