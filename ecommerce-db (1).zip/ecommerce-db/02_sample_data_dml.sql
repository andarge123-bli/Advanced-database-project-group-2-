-- ============================================================
-- Task 1 (continued): Sample Data — DML
-- ============================================================

-- Categories
INSERT INTO categories (category_id, category_name, description) VALUES
(1, 'Electronics', 'Electronic devices and gadgets'),
(2, 'Fashion', 'Clothing, shoes, and accessories'),
(3, 'Home & Kitchen', 'Household items and kitchen appliances');

-- Products
INSERT INTO products (product_id, product_name, category_id, price, description) VALUES
(1, 'Laptop', 1, 15000.00, 'High-performance laptop for work and gaming'),
(2, 'Phone', 1, 8000.00, 'Smartphone with 6.5 inch display'),
(3, 'Shoes', 2, 1200.00, 'Comfortable running shoes'),
(4, 'Headphones', 1, 2500.00, 'Wireless noise-cancelling headphones'),
(5, 'T-Shirt', 2, 500.00, 'Cotton casual t-shirt');

-- Inventory
INSERT INTO inventory (product_id, stock, warehouse) VALUES
(1, 10, 'Addis Ababa'),
(2, 20, 'Addis Ababa'),
(3, 50, 'Hawassa'),
(4, 30, 'Adama'),
(5, 100, 'Addis Ababa');

-- Customers (passwords are hashed using SHA-256 for demonstration)
INSERT INTO customers (customer_id, full_name, email, phone, password_hash, city) VALUES
(1, 'Abel', 'abel@example.com', '+251911000001',
   encode(digest('password123', 'sha256'), 'hex'), 'Addis Ababa'),
(2, 'Sara', 'sara@example.com', '+251911000002',
   encode(digest('password456', 'sha256'), 'hex'), 'Adama'),
(3, 'Dawit', 'dawit@example.com', '+251911000003',
   encode(digest('password789', 'sha256'), 'hex'), 'Hawassa');

-- Orders
INSERT INTO orders (order_id, customer_id, total_amount, status, shipping_city) VALUES
(1, 1, 8000.00, 'Delivered', 'Addis Ababa'),
(2, 2, 15000.00, 'Placed', 'Adama');

-- Order Items
INSERT INTO order_items (order_item_id, order_id, product_id, quantity, unit_price) VALUES
(1, 1, 2, 1, 8000.00),
(2, 2, 1, 1, 15000.00);

-- Payments
INSERT INTO payments (payment_id, order_id, payment_method, amount, status, transaction_ref) VALUES
(1, 1, 'Telebirr', 8000.00, 'Completed', 'TXN-TB-00001'),
(2, 2, 'Cash on Delivery', 15000.00, 'Pending', NULL);

-- Reset sequences to avoid conflicts with future inserts
SELECT setval('categories_category_id_seq', (SELECT MAX(category_id) FROM categories));
SELECT setval('products_product_id_seq', (SELECT MAX(product_id) FROM products));
SELECT setval('customers_customer_id_seq', (SELECT MAX(customer_id) FROM customers));
SELECT setval('orders_order_id_seq', (SELECT MAX(order_id) FROM orders));
SELECT setval('order_items_order_item_id_seq', (SELECT MAX(order_item_id) FROM order_items));
SELECT setval('payments_payment_id_seq', (SELECT MAX(payment_id) FROM payments));
