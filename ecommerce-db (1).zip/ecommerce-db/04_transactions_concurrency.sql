-- ============================================================
-- Task 3: Transactions & Concurrency Control
-- ============================================================

-- -------------------------------------------------------
-- PART A: Demonstrating Concurrency Problems
-- -------------------------------------------------------

-- Problem 1: LOST UPDATE
-- Two users buy the last 2 units of the same product simultaneously.
-- Without proper isolation, one update overwrites the other.

-- Session A (User 1 buys 1 Laptop):
BEGIN;
SELECT stock FROM inventory WHERE product_id = 1; -- reads stock = 10
-- Meanwhile Session B also reads stock = 10
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1; -- sets stock = 9
COMMIT;

-- Session B (User 2 buys 1 Laptop — concurrent):
BEGIN;
SELECT stock FROM inventory WHERE product_id = 1; -- reads stock = 10 (stale!)
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1; -- sets stock = 9 (LOST UPDATE!)
COMMIT;
-- Result: Both users bought 1 unit, but stock decreased by only 1 instead of 2.

-- -------------------------------------------------------
-- Problem 2: DIRTY READ
-- One transaction reads uncommitted data from another.

-- Session A:
BEGIN;
UPDATE inventory SET stock = 0 WHERE product_id = 2; -- not yet committed
-- Session B (READ UNCOMMITTED): 
-- SELECT stock FROM inventory WHERE product_id = 2; -- reads 0 (dirty!)
ROLLBACK; -- Session A rolls back; the real stock is still 20
-- Session B used wrong data.

-- -------------------------------------------------------
-- Problem 3: NON-REPEATABLE READ
-- Same query returns different results within one transaction.

-- Session A:
BEGIN;
SELECT stock FROM inventory WHERE product_id = 3; -- reads 50
-- Session B commits: UPDATE inventory SET stock = 45 WHERE product_id = 3; COMMIT;
SELECT stock FROM inventory WHERE product_id = 3; -- now reads 45 (non-repeatable!)
COMMIT;

-- ============================================================
-- PART B: Solutions
-- ============================================================

-- -------------------------------------------------------
-- Solution 1: Using SERIALIZABLE Isolation Level
-- Prevents all anomalies (lost updates, dirty reads, non-repeatable reads, phantoms)
-- -------------------------------------------------------

-- Session A:
BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SELECT stock FROM inventory WHERE product_id = 1;
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;
COMMIT;

-- Session B (concurrent — will be blocked or aborted):
BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;
SELECT stock FROM inventory WHERE product_id = 1;
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;
COMMIT; -- PostgreSQL will detect conflict and abort one transaction

-- -------------------------------------------------------
-- Solution 2: Using READ COMMITTED (default in PostgreSQL)
-- Prevents dirty reads; still allows non-repeatable reads
-- -------------------------------------------------------
BEGIN TRANSACTION ISOLATION LEVEL READ COMMITTED;
SELECT stock FROM inventory WHERE product_id = 1;
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;
COMMIT;

-- -------------------------------------------------------
-- Solution 3: Explicit Row-Level Locking (SELECT ... FOR UPDATE)
-- Best practical solution for preventing overselling
-- -------------------------------------------------------

-- Complete Safe Purchase Transaction with Locking
BEGIN;

-- Lock the inventory row — other transactions wait here
SELECT stock FROM inventory WHERE product_id = 1 FOR UPDATE;

-- Check if stock is sufficient (application logic)
-- If stock >= requested_quantity, proceed:
UPDATE inventory SET stock = stock - 1, updated_at = NOW()
WHERE product_id = 1 AND stock >= 1;

-- If the update affected 0 rows, the product is out of stock
-- In application code: check affected rows, ROLLBACK if 0

-- Create the order
INSERT INTO orders (customer_id, total_amount, status, shipping_city)
VALUES (1, 15000.00, 'Placed', 'Addis Ababa');

-- Create order item
INSERT INTO order_items (order_id, product_id, quantity, unit_price)
VALUES (currval('orders_order_id_seq'), 1, 1, 15000.00);

-- Create payment record
INSERT INTO payments (order_id, payment_method, amount, status)
VALUES (currval('orders_order_id_seq'), 'Telebirr', 15000.00, 'Pending');

-- Log the transaction for audit
INSERT INTO audit_log (user_id, action, table_name, record_id, new_values)
VALUES (1, 'PURCHASE', 'orders', currval('orders_order_id_seq')::int,
        '{"product": "Laptop", "quantity": 1, "amount": 15000}'::jsonb);

COMMIT;

-- -------------------------------------------------------
-- Solution 4: Full ACID-Compliant Order Placement with ROLLBACK
-- -------------------------------------------------------

DO $$
DECLARE
    v_stock INT;
    v_order_id INT;
    v_product_id INT := 2;
    v_customer_id INT := 3;
    v_quantity INT := 2;
    v_unit_price DECIMAL := 8000.00;
BEGIN
    -- Lock and check inventory
    SELECT stock INTO v_stock
    FROM inventory
    WHERE product_id = v_product_id
    FOR UPDATE;

    IF v_stock < v_quantity THEN
        RAISE EXCEPTION 'Insufficient stock. Available: %, Requested: %', v_stock, v_quantity;
    END IF;

    -- Deduct inventory
    UPDATE inventory
    SET stock = stock - v_quantity, updated_at = NOW()
    WHERE product_id = v_product_id;

    -- Create order
    INSERT INTO orders (customer_id, total_amount, status, shipping_city)
    VALUES (v_customer_id, v_quantity * v_unit_price, 'Placed', 'Hawassa')
    RETURNING order_id INTO v_order_id;

    -- Create order item
    INSERT INTO order_items (order_id, product_id, quantity, unit_price)
    VALUES (v_order_id, v_product_id, v_quantity, v_unit_price);

    -- Create payment
    INSERT INTO payments (order_id, payment_method, amount, status)
    VALUES (v_order_id, 'Telebirr', v_quantity * v_unit_price, 'Pending');

    -- Audit log
    INSERT INTO audit_log (user_id, action, table_name, record_id, new_values)
    VALUES (v_customer_id, 'ORDER_PLACED', 'orders', v_order_id,
            jsonb_build_object('product_id', v_product_id, 'quantity', v_quantity,
                               'total', v_quantity * v_unit_price));

    RAISE NOTICE 'Order % placed successfully!', v_order_id;

EXCEPTION
    WHEN OTHERS THEN
        RAISE NOTICE 'Transaction failed: %. Rolling back.', SQLERRM;
        -- Transaction automatically rolls back on unhandled exception in DO block
END $$;
