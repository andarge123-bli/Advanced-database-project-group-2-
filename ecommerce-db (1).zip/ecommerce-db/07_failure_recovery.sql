-- ============================================================
-- Task 6: Failure Recovery
-- ============================================================
-- PostgreSQL uses Write-Ahead Logging (WAL) by default.
-- Below are configurations and demonstrations.

-- -------------------------------------------------------
-- PART A: WAL Configuration (postgresql.conf settings)
-- -------------------------------------------------------

-- Key WAL settings (in postgresql.conf):
-- wal_level = replica              -- Enables WAL for replication
-- max_wal_senders = 5              -- Number of concurrent WAL streaming connections
-- wal_keep_size = 1GB              -- Retain WAL files for recovery
-- archive_mode = on                -- Enable WAL archiving
-- archive_command = 'cp %p /backup/wal_archive/%f'  -- Copy WAL to archive

-- -------------------------------------------------------
-- PART B: Checkpointing Configuration
-- -------------------------------------------------------

-- PostgreSQL checkpointing settings (in postgresql.conf):
-- checkpoint_timeout = 5min        -- Time between automatic checkpoints
-- checkpoint_completion_target = 0.9  -- Spread I/O over 90% of checkpoint interval
-- max_wal_size = 2GB               -- Trigger checkpoint when WAL reaches this size

-- Force a manual checkpoint
CHECKPOINT;

-- -------------------------------------------------------
-- PART C: Backup Strategies
-- -------------------------------------------------------

-- 1. Logical Backup (pg_dump)
-- Full database backup:
-- pg_dump -U admin_user -d ecommerce -F c -f /backup/ecommerce_full.dump

-- Table-specific backup:
-- pg_dump -U admin_user -d ecommerce -t orders -t payments -F c -f /backup/orders_payments.dump

-- 2. Physical Backup (pg_basebackup — for Point-in-Time Recovery)
-- pg_basebackup -U replicator -D /backup/base_backup -Fp -Xs -P

-- 3. Restore from backup:
-- pg_restore -U admin_user -d ecommerce -c /backup/ecommerce_full.dump

-- -------------------------------------------------------
-- PART D: Crash Recovery Scenario Simulation
-- -------------------------------------------------------

-- Scenario: System crashes during order payment processing
-- Step 1: Customer places order and payment begins
BEGIN;

-- Deduct inventory
UPDATE inventory SET stock = stock - 1 WHERE product_id = 1;

-- Create order
INSERT INTO orders (customer_id, total_amount, status, shipping_city)
VALUES (1, 15000.00, 'Placed', 'Addis Ababa');

-- Create payment — CRASH HAPPENS HERE before COMMIT
INSERT INTO payments (order_id, payment_method, amount, status)
VALUES (currval('orders_order_id_seq'), 'Telebirr', 15000.00, 'Pending');

-- *** SIMULATED CRASH — transaction never committed ***
-- PostgreSQL behavior on restart:
-- 1. Reads WAL (Write-Ahead Log) from last checkpoint
-- 2. REDO phase: Replays committed transactions from WAL
-- 3. UNDO phase: Rolls back uncommitted transactions
-- 4. Since this transaction was NOT committed, ALL changes are rolled back:
--    - Inventory stock restored to original value
--    - Order is not created
--    - Payment is not created
-- 5. Database is consistent — as if the transaction never happened

ROLLBACK; -- Simulating the automatic rollback after crash recovery

-- -------------------------------------------------------
-- PART E: Point-in-Time Recovery (PITR) Example
-- -------------------------------------------------------

-- To restore database to a specific point in time:
-- 1. Stop PostgreSQL
-- 2. Restore base backup:
--    cp -r /backup/base_backup /var/lib/postgresql/data
-- 3. Create recovery.conf (PostgreSQL < 12) or postgresql.auto.conf:
--    restore_command = 'cp /backup/wal_archive/%f %p'
--    recovery_target_time = '2024-12-15 14:30:00'
-- 4. Create recovery.signal file
-- 5. Start PostgreSQL — it replays WAL up to the target time

-- -------------------------------------------------------
-- PART F: Automated Backup Script (Shell — for reference)
-- -------------------------------------------------------

-- #!/bin/bash
-- # Daily backup script
-- BACKUP_DIR="/backup/daily"
-- DATE=$(date +%Y%m%d_%H%M%S)
-- DB_NAME="ecommerce"
--
-- # Create backup
-- pg_dump -U admin_user -d $DB_NAME -F c -f $BACKUP_DIR/ecommerce_$DATE.dump
--
-- # Keep only last 7 days of backups
-- find $BACKUP_DIR -name "*.dump" -mtime +7 -delete
--
-- # Verify backup integrity
-- pg_restore --list $BACKUP_DIR/ecommerce_$DATE.dump > /dev/null 2>&1
-- if [ $? -eq 0 ]; then
--     echo "Backup successful: ecommerce_$DATE.dump"
-- else
--     echo "Backup verification FAILED!" | mail -s "Backup Alert" admin@example.com
-- fi
